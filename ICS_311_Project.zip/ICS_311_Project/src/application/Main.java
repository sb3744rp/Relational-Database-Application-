package application;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Main extends Application {
	
	Stage window;
	static Form2 form2Object;
	Scene firstScene, introScene;
	static Statement st;
	static ResultSet rs;
	static Connection con;
	
	@Override
	public void start(Stage primaryStage) throws FileNotFoundException {
	
	//set window as primary stage for easier referencing 
	window = primaryStage;
	
	
	//intro scene
	IntroScreen introScreenObj = new IntroScreen();
	introScene = introScreenObj.getIntroScene();
	Button transitionSceneButton = introScreenObj.getTransitionButton();
	
	transitionSceneButton.setOnAction(e->
	{
		window.setScene(firstScene);
		connectToDB();
	});
	
//********************************************************************************************************************************
	// Form 2 Scene
	//takes user input, joins tables, and displays info in designated forms 
	
	
	form2Object = new Form2();
	firstScene = form2Object.getScene1();
		
	// obtain access to care provider id form from form 2 class
	TextField userInputForm = form2Object.getCareProvdiderIdForm();
	
	//obtain access to care provider street address form
	TextField streetAddressForm = form2Object.getCareProviderStreetAddressForm();
	
	// obtain access to care provider city form
	TextField cityForm = form2Object.getCareProviderCityForm();
	
	// obtain access to care provider zip form
	TextField zipForm = form2Object.getCareProviderZipForm();
	
	// obtain access to submit button
	Button submitButton = form2Object.getCareProviderSubmitButton();
	
	//obtain forward and backward buttons
	Button forwardButton = form2Object.getForward();
	Button backwardButton = form2Object.getBackward();
	
	//obtain close DB button
	Button closeDBButton = form2Object.getCloseDB();
	
	closeDBButton.setOnAction(e->
	{
		closeDB();
		AlertBox.display("", "Database connection closed!");
	});
	
	submitButton.setOnAction(e->
	{	
		executeQuery(userInputForm.getText());
	});
	
	forwardButton.setOnAction(e->
	{
		try 
		{
			int extractedId;
			String newId;
		
			extractedId = Integer.parseInt(userInputForm.getText());
			extractedId++;
		
			newId = ""+extractedId;
		
			executeQuery(newId);
		}
		catch(Exception a) 
		{
	
		}
	});
	
	backwardButton.setOnAction(e->
	{
		try 
		{
			int extractedId;
			String newId;
		
			extractedId = Integer.parseInt(userInputForm.getText());
			extractedId--;
		
			newId = ""+extractedId;
		
			executeQuery(newId);
		}
		catch(Exception a) 
		{
			
		}
	});
	
	
	
	window.setScene(introScene);
	window.show();
}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public static void connectToDB() {
		try 
		{
       		Class.forName("com.mysql.jdbc.Driver");
       		con = DriverManager.getConnection("jdbc:mysql://localhost/ics311project?user=root&password=ics311");
       		System.out.println("Connection Object Created : " + con);
		}
       		
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}	
	}//end of connect to DB
	
	
	public static void closeDB() {
		try 
		{
			st.close();
			rs.close();
			con.close();
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}//end of closeDB
	
	
	public static void executeQuery(String target) { 
   		 try 
   		 {
   			int id;
   			id = Integer.parseInt(target);
   			
   			st = con.createStatement();
			rs = st.executeQuery("select fosterHomeStreet,fosterHomeCity, fosterHomeState,fosterHomeZip\r\n" + 
					"from fostercareprovider join fosterHome\r\n" + 
					"where fostercareprovider.fosterHomeId = fosterHome.fosterHomeId\r\n" + 
					"and fostercareprovider.careProviderId ="+id);
			
			 if (rs.next()) 
	   		 {
				form2Object.setCareProvdiderIdForm(target);
	   			form2Object.getCareProviderStreetAddressForm().setText(rs.getString("fosterHomeStreet"));
	   			form2Object.getCareProviderCityForm().setText(rs.getString("fosterHomeCity"));
	   			form2Object.getCareProviderStateForm().setText(rs.getString("fosterHomeState"));
	   			form2Object.getCareProviderZipForm().setText(rs.getString("fosterHomeZip"));
	   		 }
			 else
				 throw new Exception();
		} 
   		 catch (Exception a) 
   		 {
			AlertBox.display("ERROR", "End of result set reached or invalid ID entered!");
		 }
	}//end of execute query
}
		

