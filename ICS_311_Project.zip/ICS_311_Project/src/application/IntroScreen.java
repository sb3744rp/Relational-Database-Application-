package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class IntroScreen {
	Text introScreenTitle, description;
	BorderPane introSceneContentHolder;
	VBox holdsAppDescription;
	Button transitionButton;
	Scene introScene;
	Image background,dakota,ramsey,scott,hennepin,mnDHS;
	ImageView dk,rs,sc,hp,mn;
	FlowPane holdsLogos;

	
	
	public IntroScreen() throws FileNotFoundException 
	{
		
		//establish layout of objects used to hold nodes
		introScreenTitle = new Text();
		introSceneContentHolder = new BorderPane();
		holdsAppDescription = new VBox();
		transitionButton = new Button("Continue");
		description = new Text();
		holdsLogos = new FlowPane();
		
		
		//set relative image path for images used in scene
		background = new Image(new FileInputStream((".\\bin\\application\\background.jpg")));
		dakota = new Image(new FileInputStream((".\\bin\\application\\dakota.png")));
		ramsey = new Image(new FileInputStream((".\\bin\\application\\ramsey.jpg")));
		scott = new Image(new FileInputStream((".\\bin\\application\\Scott.png")));
		hennepin = new Image(new FileInputStream((".\\bin\\application\\hennepin.png")));
		mnDHS = new Image(new FileInputStream((".\\bin\\application\\MN_DHS.jpg")));
		
		//set up dakota county image
		dk = new ImageView(dakota);
		dk.setFitHeight(100);
		dk.setFitWidth(100);
		
		// set up ramsey county image
		rs = new ImageView(ramsey);
		rs.setFitHeight(100);
		rs.setFitWidth(100);
		
		//set up hennepin county image 
		hp = new ImageView(hennepin);
		hp.setFitHeight(100);
		hp.setFitWidth(100);
		
		//set up scott county image
		sc = new ImageView(scott);
		sc.setFitHeight(100);
		sc.setFitWidth(100);
		
		
		//set up mn DHS image 
		mn = new ImageView(mnDHS);
		mn.setFitHeight(100);
		mn.setFitWidth(100);
		
		//set up flow pane which holds county logos
		holdsLogos.getChildren().addAll(dk,rs,hp,sc,mn);
		holdsLogos.setHgap(10);
		
		//set up background image for use in scene
		BackgroundImage bgImg = new BackgroundImage(background, 
		BackgroundRepeat.NO_REPEAT,
		BackgroundRepeat.NO_REPEAT,
		BackgroundPosition.DEFAULT,
		BackgroundSize.DEFAULT);
		
		//set up intro scene title
		introScreenTitle.setText("MN Adult Foster Care\nDatabase Application");
		introScreenTitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 35));
		introScreenTitle.setStroke(Color.BLACK);
		introScreenTitle.setFill(Color.WHITESMOKE);
		
		//add instructions for user 
		description.setText("Click the button below to set up a database connection and continue..");
		description.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 19));
		description.setStroke(Color.BLACK);
		description.setFill(Color.WHITESMOKE);
		
		//set up holder for logos, user instructions and transition scene button 
		holdsAppDescription.getChildren().addAll(description,transitionButton);
		holdsAppDescription.setSpacing(10);
		
		//set positioning of holders for main border pane
		introSceneContentHolder.setTop(introScreenTitle);
		introSceneContentHolder.setCenter(holdsLogos);
		introSceneContentHolder.setBottom(holdsAppDescription);
		
		//set alignment of content holders in border pane 
		introSceneContentHolder.setAlignment(introScreenTitle, Pos.CENTER);
		holdsLogos.setAlignment(Pos.CENTER);
		holdsAppDescription.setAlignment(Pos.CENTER);
		
		//set margins for content inside border pane 
		introSceneContentHolder.setMargin(holdsAppDescription, new Insets(68,50,200,0));
		introSceneContentHolder.setMargin(holdsLogos, new Insets(100,0,0,0));
		introSceneContentHolder.setMargin(introScreenTitle, new Insets(0,50,20,0));
		
		
		introSceneContentHolder.setBackground(new Background(bgImg));
		
		introScene = new Scene(introSceneContentHolder,800,600);
	}


	public Text getIntroScreenTitle() {
		return introScreenTitle;
	}


	public BorderPane getIntroSceneContentHolder() {
		return introSceneContentHolder;
	}


	public VBox getHoldsAppDescription() {
		return holdsAppDescription;
	}


	public Button getTransitionButton() {
		return transitionButton;
	}


	public Text getDescription() {
		return description;
	}


	public Scene getIntroScene() {
		return introScene;
	}
	
	
	

}
