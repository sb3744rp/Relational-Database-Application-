/** 
 * FileMenu JavaFx Class holds JavaFx code for a predefined GUI menu bar. The menu bar comes with three menu options that allow 
 * the user to choose between creating, editing or displaying a car collection. This class mainly deals with setting up the 
 * GUI appearance for the 'Main' Java Class.
 * 
 * Source of borrowed code: 
 * GitHub --> https://github.com/buckyroberts/Source-Code-from-Tutorials/blob/master/JavaFX/024_menus/Main.java
 * YouTube Tutorial--> https://www.youtube.com/watch?v=JBJ9MIEfU3k
 * 
 * 
 * @author: Jon Prendergast
 * @since: 6/12/2019
 * @version: 1.0
 * 
 */
package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class FileMenu {
	
	private Menu queryOption,queryOption2;
	private MenuBar menuBar;
	private MenuItem careProviderAddress,careProviderContact;
	private Scene fileMenuScene;
	private FlowPane holdsClickableImgs;
	private VBox clickableImg,clickableImg2,clickableImg3,clickableImg4,clickableImg5,clickableImg6;
	private Text textForImg1, textForImg2, textForImg3, textForImg4,textForImg5,textForImg6;
	private Image image,image2,image3,image4,image5,image6;
	private ImageView imageView,imageView2,imageView3,imageView4,imageView5,imageView6;
	


	public FileMenu() throws FileNotFoundException {
		
		//create fileMenu tab for drop down options 
		queryOption = new Menu("Edit...");
		queryOption2 = new Menu("Show Me...");
		
		holdsClickableImgs = new FlowPane();

		//clickable image holder box
		clickableImg = new VBox();
		clickableImg2 = new VBox();
		clickableImg3 = new VBox();
		clickableImg4 = new VBox();
		clickableImg5 = new VBox();
		clickableImg6 = new VBox();
		
		textForImg1 = new Text("Care Provider Info");
		textForImg2 = new Text("Licenser Info");
		textForImg3 = new Text("Medication Info");
		textForImg4 = new Text("Foster Home Info");
		textForImg5 = new Text("Primary Clinic Info");
		textForImg6 = new Text("Foster Client Info");
		
		image = new Image(new FileInputStream(".\\bin\\application\\ProviderImg.png"));
		imageView = new ImageView(image);
		imageView.setFitHeight(100);
		imageView.setFitWidth(100);
		
		image2 = new Image(new FileInputStream(".\\bin\\application\\License.png"));
		imageView2 = new ImageView(image2);
		imageView2.setFitHeight(100);
		imageView2.setFitWidth(100);
		
		image3 = new Image(new FileInputStream(".\\bin\\application\\medication.jfif"));
		imageView3 = new ImageView(image3);
		imageView3.setFitHeight(100);
		imageView3.setFitWidth(100);
		
		image4 = new Image(new FileInputStream(".\\bin\\application\\home.png"));
		imageView4 = new ImageView(image4);
		imageView4.setFitHeight(100);
		imageView4.setFitWidth(100);
		
		image5 = new Image(new FileInputStream(".\\bin\\application\\Clinic.jfif"));
		imageView5 = new ImageView(image5);
		imageView5.setFitHeight(100);
		imageView5.setFitWidth(100);
		
		image6 = new Image(new FileInputStream(".\\bin\\application\\client.png"));
		imageView6 = new ImageView(image6);
		imageView6.setFitHeight(90);
		imageView6.setFitWidth(90);
		
		clickableImg.getChildren().addAll(imageView,textForImg1);
		clickableImg2.getChildren().addAll(imageView2,textForImg2);
		clickableImg3.getChildren().addAll(imageView3,textForImg3);
		clickableImg4.getChildren().addAll(imageView4,textForImg4);
		clickableImg5.getChildren().addAll(imageView5,textForImg5);
		clickableImg6.getChildren().addAll(imageView6,textForImg6);
		
		holdsClickableImgs.getChildren().addAll(clickableImg,clickableImg2,clickableImg3,clickableImg4,clickableImg5,clickableImg6);
		holdsClickableImgs.setHgap(60);
		holdsClickableImgs.setVgap(60);
		
		
		//Menu drop down options 
				
		//adds a separator between menu items
		queryOption.getItems().add(new SeparatorMenuItem()); 
		
		//creates menuItem option and assigns it to fileMenu object
		careProviderAddress = new MenuItem("Care Provider Addresses");
		careProviderContact = new MenuItem("Care Provider Phone Numbers");

	
		queryOption.getItems().addAll(careProviderAddress);
		queryOption2.getItems().addAll(careProviderContact);
				
		//create main menu bar and add menu options
		menuBar = new MenuBar();
		menuBar.getMenus().addAll(queryOption,queryOption2);
	}
	

	public MenuItem getCareProviderContact() {
		return careProviderContact;
	}


	public FlowPane getHoldsClickableImgs() {
		return holdsClickableImgs;
	}

	public VBox getClickableImg() {
		return clickableImg;
	}
	
	
	public VBox getClickableImg2() {
		return clickableImg2;
	}


	public VBox getClickableImg3() {
		return clickableImg3;
	}
	
	
	public VBox getClickableImg4() {
		return clickableImg4;
	}

	public VBox getClickableImg5() {
		return clickableImg5;
	}
	
	public VBox getClickableImg6() {
		return clickableImg6;
	}

	/**
	 * 
	 * 
	 * @return fileMenuScene
	 */
	
	public Scene getFileMenuScene() {
		return fileMenuScene;
	}

	/**
	 * 'getCreateOption' method returns a reference to the menu option
	 *  for initiating car collection creation.
	 * 
	 * @return: createOption
	 */
	public Menu getCreateOption() {
		return queryOption;
	}

	/**
	 * 'getMenuBar' method returns a reference to the menu bar
	 *  which holds all menu options
	 * 
	 * @return: menuBar
	 */
	public MenuBar getMenuBar() {
		return menuBar;
	}

	/**
	 * 'getAddCarToCollection' method returns a reference to the drop down menu item
	 *  for adding a car to the collection. 
	 * 
	 * @return: addCarToCollection
	 */
	public MenuItem getCareProviderAddress() {
		return careProviderAddress;
	}
	
	/**
	 * 'getRemoveFromCarCollection' method returns a reference to the drop down menu item
	 *  for removing a car from the collection.
	 *  
	 * @return: removeFromCarCollection
	 */
}
