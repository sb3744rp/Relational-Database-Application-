package application;

public class LicenseRenewal {
	
	private String licensingId;
	private String licensorCounty;
	private String licensorLastName;
	private String licensorFirstName;
	private String initialLicensingDate;
	private String latestLicensingDate;
	private String licenseRenewalDate;
	private String rowCreation;
	private String rowUpdate;
	
	public LicenseRenewal(String licensingId, String licensorCounty, String licensorLastName, String licensorFirstName,
			String initialLicensingDate, String latestLicensingDate, String licenseRenewalDate,
			String rowCreation, String rowUpdate) {
		this.licensingId = licensingId;
		this.licensorCounty = licensorCounty;
		this.licensorLastName = licensorLastName;
		this.licensorFirstName = licensorFirstName;
		this.initialLicensingDate = initialLicensingDate;
		this.latestLicensingDate = latestLicensingDate;
		this.licenseRenewalDate = licenseRenewalDate;
		this.rowCreation = rowCreation;
		this.rowUpdate = rowUpdate;
	}
	public String getLicensingId() {
		return licensingId;
	}
	public void setLicensingId(String licensingId) {
		this.licensingId = licensingId;
	}
	public String getLicensorCounty() {
		return licensorCounty;
	}
	public void setLicensorCounty(String licensorCounty) {
		this.licensorCounty = licensorCounty;
	}
	public String getLicensorLastName() {
		return licensorLastName;
	}
	public void setLicensorLastName(String licensorLastName) {
		this.licensorLastName = licensorLastName;
	}
	public String getLicensorFirstName() {
		return licensorFirstName;
	}
	public void setLicensorFirstName(String licensorFirstName) {
		this.licensorFirstName = licensorFirstName;
	}
	
	public String getInitialLicensingDate() {
		return initialLicensingDate;
	}
	public void setInitialLicensingDate(String initialLicensingDate) {
		this.initialLicensingDate = initialLicensingDate;
	}
	public String getLatestLicensingDate() {
		return latestLicensingDate;
	}
	public void setLatestLicensingDate(String latestLicensingDate) {
		this.latestLicensingDate = latestLicensingDate;
	}
	public String getLicenseRenewalDate() {
		return licenseRenewalDate;
	}
	public void setLicenseRenewalDate(String licenseRenewalDate) {
		this.licenseRenewalDate = licenseRenewalDate;
	}
	public String getRowCreation() {
		return rowCreation;
	}
	public void setRowCreation(String rowCreation) {
		this.rowCreation = rowCreation;
	}
	public String getRowUpdate() {
		return rowUpdate;
	}
	public void setRowUpdate(String rowUpdate) {
		this.rowUpdate = rowUpdate;
	}
}
