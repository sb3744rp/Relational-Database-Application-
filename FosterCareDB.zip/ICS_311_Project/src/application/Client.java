package application;

public class Client {
	
	private String clientId;
	private String fosterHomeId;
	private String clientLastName;
	private String clientFirstName;
	private String clientMiddleName;
	private String clientDateOfBirth;
	private String rowCreationDate;
	private String latestRowUpdate;
	private String primaryClinicId;
	private String gender;
	
	public Client(String clientId, String fosterHomeId, String clientLastName, String clientFirstName,
			String clientMiddleName, String clientDateOfBirth, String rowCreationDate, String latestRowUpdate,
			String primaryClinicId, String gender) {
		super();
		this.clientId = clientId;
		this.fosterHomeId = fosterHomeId;
		this.clientLastName = clientLastName;
		this.clientFirstName = clientFirstName;
		this.clientMiddleName = clientMiddleName;
		this.clientDateOfBirth = clientDateOfBirth;
		this.rowCreationDate = rowCreationDate;
		this.latestRowUpdate = latestRowUpdate;
		this.primaryClinicId = primaryClinicId;
		this.gender = gender;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getFosterHomeId() {
		return fosterHomeId;
	}

	public void setFosterHomeId(String fosterHomeId) {
		this.fosterHomeId = fosterHomeId;
	}

	public String getClientLastName() {
		return clientLastName;
	}

	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}

	public String getClientFirstName() {
		return clientFirstName;
	}

	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}

	public String getClientMiddleName() {
		return clientMiddleName;
	}

	public void setClientMiddleName(String clientMiddleName) {
		this.clientMiddleName = clientMiddleName;
	}

	public String getClientDateOfBirth() {
		return clientDateOfBirth;
	}

	public void setClientDateOfBirth(String clientDateOfBirth) {
		this.clientDateOfBirth = clientDateOfBirth;
	}

	public String getRowCreationDate() {
		return rowCreationDate;
	}

	public void setRowCreationDate(String rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}

	public String getLatestRowUpdate() {
		return latestRowUpdate;
	}

	public void setLatestRowUpdate(String latestRowUpdate) {
		this.latestRowUpdate = latestRowUpdate;
	}

	public String getPrimaryClinicId() {
		return primaryClinicId;
	}

	public void setPrimaryClinicId(String primaryClinicId) {
		this.primaryClinicId = primaryClinicId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
}
