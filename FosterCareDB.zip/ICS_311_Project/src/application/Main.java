package application;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main extends Application {
	
	Stage window;
	static Form careProviderInfoForm;
	static CareProviderRelation careProviderRelationObject;
	static CareProviderContactInfoRelation additionalCPInfoObject;
	Scene careProviderScene, introScene, menuScene, careProviderRelationScene,cpMoreInfoScene,licenseRenewalRelationScene, 
	fosterHomeScene, medicationChartScene, primaryClinicScene,clientScene;
	static Statement st;
	static ResultSet rs;
	static Connection con;
	
	@Override
	public void start(Stage primaryStage) throws FileNotFoundException {
	
	//set window as primary stage for easier referencing 
	window = primaryStage;

//****************************************************************************************
// Introduction scene set up
	
	//introduction scene object creation
	IntroScreen introScreenObj = new IntroScreen();
	
	//introduction scene reference called
	introScene = introScreenObj.getIntroScene();
	
//****************************************************************************************
// File Menu scene set up
	
	//create a stack pane to hold menu bar
	StackPane holdsMenuBar = new StackPane();

	//create file menu to hold menu options
	FileMenu menuOptions = new FileMenu();
	
	//create file menu holder
	BorderPane holdsAllMenu = new BorderPane();
	
	//create menu bar to hold file menu options
	MenuBar holdsMenuOptions = menuOptions.getMenuBar();
	
	//add menu options to menu bar
	holdsMenuBar.getChildren().add(holdsMenuOptions);
	
	//Flow pane holds all clickable images
	FlowPane holdsAllImgs = menuOptions.getHoldsClickableImgs();
	
	//set node alignment within borderpane
	holdsAllMenu.setTop(holdsMenuBar);
	holdsAllMenu.setCenter(holdsAllImgs);
	holdsAllMenu.setMargin(holdsAllImgs, new Insets(60,80,100,80));

	//access clickable images for action events
	VBox careProviderMenuOption = menuOptions.getClickableImg();
	VBox licenserMenuOption = menuOptions.getClickableImg2();
	VBox clientMedChartOption = menuOptions.getClickableImg3();
	VBox fosterHomeMenuOption = menuOptions.getClickableImg4();
	VBox primaryClinicMenuOption = menuOptions.getClickableImg5();
	VBox clientMenuOption = menuOptions.getClickableImg6();
	
	//access care provider address info
	MenuItem careProviderAddressInfo = menuOptions.getCareProviderAddress();
	MenuItem careProviderPhoneInfo = menuOptions.getCareProviderContact();
	
	
	//create scene to hold stack pane
	menuScene = new Scene(holdsAllMenu,600,600);
	
//****************************************************************************************	 
// Care Provider Info Scene
// shows foster home address info
		
	careProviderInfoForm = new Form();
	careProviderScene = careProviderInfoForm.getScene();
			
	// obtain access to care provider id form from form 2 class
	TextField userInputForm = careProviderInfoForm.getCareProvdiderIdForm();

	// obtain access to submit button
	Button submitButton = careProviderInfoForm.getCareProviderSubmitButton();
		
	//obtain forward and backward buttons
	Button forwardButton = careProviderInfoForm.getForward();
	Button backwardButton = careProviderInfoForm.getBackward();
		
	//buttons
	Button returnToMenu = careProviderInfoForm.getReturnToMenu();
	
	
//****************************************************************************************	 
// Care Provider Phone Info Scene
// shows name and phone number info
	
	additionalCPInfoObject = new CareProviderContactInfoRelation();
	cpMoreInfoScene = additionalCPInfoObject.getAdditionalProviderInfoScene();
	TableView providerTable =additionalCPInfoObject.getTable(); 
	
	Button returnToMenuButton = additionalCPInfoObject.getReturnButton();
	Button displayListButton = additionalCPInfoObject.getRefreshButton();
	
	displayListButton.setOnAction(e->{
		try {
			providerTable.setItems(providerInfoListDisplay());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	});
	
//****************************************************************************************	 
// Care Provider Relation Scene
// shows care provider relation from SQL
	
	careProviderRelationObject = new CareProviderRelation();
	careProviderRelationScene = careProviderRelationObject.getCareProviderRelationScene();
	
	Button returnToMenu2 = careProviderRelationObject.getReturnButton();
	Button displayListButton2 = careProviderRelationObject.getRefreshButton();
	TableView careProviderRelation = careProviderRelationObject.getTable();
	
	returnToMenu2.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton2.setOnAction(e->{
		try {
			careProviderRelation.setItems(showCareProviderRelation());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	});
//****************************************************************************************
// License Renewal Relation Scene
	
	LicenseRenewalRelation licenseRenewalRelationObject = new LicenseRenewalRelation();
	licenseRenewalRelationScene = licenseRenewalRelationObject.getLicenseRenewalScene();
	TableView licensorTable = licenseRenewalRelationObject.getTable();
	
	Button returnToMenuButton3 = licenseRenewalRelationObject.getReturnButton();
	Button displayListButton3 = licenseRenewalRelationObject.getRefreshButton();
	
	returnToMenuButton3.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton3.setOnAction(e->{
		try {
			licensorTable.setItems(showLicenseRenewalRelation());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
	});
	
//****************************************************************************************
// Foster Home Relation Scene
	
	FosterCareHomeRelation fosterHomeObject = new FosterCareHomeRelation();
	fosterHomeScene = fosterHomeObject.getAdditionalProviderInfoScene();
	TableView fosterHomeTable = fosterHomeObject.getTable();
	
	Button returnToMenuButton4 = fosterHomeObject.getReturnButton();
	Button displayListButton4 = fosterHomeObject.getRefreshButton();
	
	returnToMenuButton4.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton4.setOnAction(e->{
		try {
			fosterHomeTable.setItems(showFosterHomeRelation());
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
	});
	
	
//****************************************************************************************
// Client Med Chart Scene
	
	MedicationChartRelation medicationChartObj = new MedicationChartRelation();
	medicationChartScene = medicationChartObj.getAdditionalProviderInfoScene();
	TableView medicationChartTable = medicationChartObj.getTable();
	
	Button returnToMenuButton5 = medicationChartObj.getReturnButton();
	Button displayListButton5 = medicationChartObj.getRefreshButton();
	
	returnToMenuButton5.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton5.setOnAction(e->{
		try {
			medicationChartTable.setItems(showMedChartRelation());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	});
	
	
//****************************************************************************************
// Primary Clinic Scene
	
	PrimaryClinicRelation primaryClinicObj = new PrimaryClinicRelation();
	primaryClinicScene = primaryClinicObj.getAdditionalProviderInfoScene();
	TableView primaryClinicTable = primaryClinicObj.getTable();
	
	Button returnToMenuButton6 = primaryClinicObj.getReturnButton();
	Button displayListButton6 = primaryClinicObj.getRefreshButton();
	
	returnToMenuButton6.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton6.setOnAction(e->{
		
		try {
			primaryClinicTable.setItems(showPrimaryClinicRelation());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	});
	
//****************************************************************************************
// Foster Care Client Scene
	
	ClientRelation clientRelationObj = new ClientRelation();
	clientScene = clientRelationObj.getAdditionalProviderInfoScene();
	TableView clientTable = clientRelationObj.getTable();
	
	Button returnToMenuButton7 = clientRelationObj.getReturnButton();
	Button displayListButton7 = clientRelationObj.getRefreshButton();
	
	returnToMenuButton7.setOnAction(e->{
		window.setScene(menuScene);
	});
	
	displayListButton7.setOnAction(e->{
		try {
			clientTable.setItems(showClientRelation());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
	});
	
//****************************************************************************************
// Transition from introduction scene to file menu scene
	
	//transition button for introduction scene --> care provider scene
	Button transitionSceneButton = introScreenObj.getTransitionButton();
	
	//action event for scene transition 
	transitionSceneButton.setOnAction(e->
	{
		window.setScene(menuScene);
		connectToDB();
	});
	
//********************************************************************************************************************************
// Transition from file menu scene to care provider address form
	
   careProviderAddressInfo.setOnAction(e->
   {
	   window.setScene(careProviderScene);
   });
   
//******************************************************************************************************************************** 
// Transition from care provider address form to file menu scene 
	
   returnToMenu.setOnAction(e->
   {
	   window.setScene(menuScene);
   });
   
//********************************************************************************************************************************   
// Transition from file menu to care provider relation 
	
   careProviderMenuOption.setOnMouseClicked(e->{
		window.setScene(careProviderRelationScene);
	});
   
   
 //********************************************************************************************************************************  
// Transition from fileMenu to licenser table
   
   licenserMenuOption.setOnMouseClicked(e->{
	   window.setScene(licenseRenewalRelationScene);
   });
   
//********************************************************************************************************************************  
// Transition from fileMenu to foster home table
   
   fosterHomeMenuOption.setOnMouseClicked(e->{
	   
	   window.setScene(fosterHomeScene);
   });
   
   
//********************************************************************************************************************************  
// Transition from fileMenu to additional care provider phone listing

   careProviderPhoneInfo.setOnAction(e->{
	   window.setScene(cpMoreInfoScene);
   });
   
   
//********************************************************************************************************************************  
// Transition from providerInfoScene to menu scene
   returnToMenuButton.setOnAction(e->{
	   window.setScene(menuScene);
   });
   
//********************************************************************************************************************************  
// Transition from file menu to medication chart relation scene
   
   clientMedChartOption.setOnMouseClicked(e->{
	   window.setScene(medicationChartScene);
   });
   
   
//********************************************************************************************************************************  
// Transition from file menu to primary clinic scene
   primaryClinicMenuOption.setOnMouseClicked(e->{
	   window.setScene(primaryClinicScene);
   });
   
   
//********************************************************************************************************************************  
// Client transition from file menu to client relation scene
   clientMenuOption.setOnMouseClicked(e->{
	   window.setScene(clientScene);	   
   });
   
//********************************************************************************************************************************  

	//action event for submit query button 
	submitButton.setOnAction(e->
	{	
		careProviderQuery(userInputForm.getText());
	});
	
	//action event for forward scroll button 
	forwardButton.setOnAction(e->
	{
		buttonForward(userInputForm);
	});
	
	//action event for backward scroll button
	backwardButton.setOnAction(e->
	{
		buttonBackward(userInputForm);
	});

//********************************************************************************************************************************
	
	window.setScene(introScene);
	window.show();
}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public static void connectToDB() {
		try 
		{
       		Class.forName("com.mysql.jdbc.Driver");
       		con = DriverManager.getConnection("jdbc:mysql://localhost/ics311project?user=root&password=ics311");
       		System.out.println("Connection Object Created : " + con);
		}
       		
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}	
	}//end of connect to DB
	
	
	public static void closeDB() {
		try 
		{
			st.close();
			rs.close();
			con.close();
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}//end of closeDB
	
	
	public static void careProviderQuery(String target) { 
   		 try 
   		 {
   			int id;
   			id = Integer.parseInt(target);
   			
   			st = con.createStatement();
			rs = st.executeQuery("select fosterHomeStreet,fosterHomeCity, fosterHomeState,fosterHomeZip\r\n" + 
					"from fostercareprovider join fosterHome\r\n" + 
					"where fostercareprovider.fosterHomeId = fosterHome.fosterHomeId\r\n" + 
					"and fostercareprovider.careProviderId ="+id);
			
			 if (rs.next()) 
	   		 {
				careProviderInfoForm.setCareProvdiderIdForm(target);
	   			careProviderInfoForm.getCareProviderStreetAddressForm().setText(rs.getString("fosterHomeStreet"));
	   			careProviderInfoForm.getCareProviderCityForm().setText(rs.getString("fosterHomeCity"));
	   			careProviderInfoForm.getCareProviderStateForm().setText(rs.getString("fosterHomeState"));
	   			careProviderInfoForm.getCareProviderZipForm().setText(rs.getString("fosterHomeZip"));
	   		 }
			 else
				 throw new Exception();
		} 
   		 catch (Exception a) 
   		 {
			AlertBox.display("ERROR", "End of result set reached or invalid ID entered!");
		 }
	}//end of execute query

	
	/**
	 *'buttonForward' allows the user to scroll forward through the data within a given relation
	 * 
	 * @param inputForm
	 */
	public static void buttonForward(TextField inputForm) {
		try 
		{
			int extractedId;
			String newId;
		
			extractedId = Integer.parseInt(inputForm.getText());
			extractedId++;
		
			newId = ""+extractedId;
		
			careProviderQuery(newId);
		}
		catch(Exception a) 
		{
	
		}
	}// end of buttonForward method
	
	
	/**
	 *'buttonBackward' allows the user to scroll backward through the data within a given relation
	 * 
	 * @param inputForm
	 */
	public static void buttonBackward(TextField inputForm) {
		try 
		{
			int extractedId;
			String newId;
		
			extractedId = Integer.parseInt(inputForm.getText());
			extractedId--;
		
			newId = ""+extractedId;
		
			careProviderQuery(newId);
		}
		catch(Exception a) 
		{
			
		}
	}//end of buttonBackward method

	
	/**
	 * 
	 * @return list
	 * @throws SQLException 
	 */
	public ObservableList<CareProvider> showCareProviderRelation() throws SQLException
	{
		ObservableList<CareProvider> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select careProviderId, fosterHomeId, careProviderLastName, careProviderFirstName, careProviderDateOfBirth, rowCreationUpdate,latestRowUpdate\r\n" + 
				"from fostercareprovider;");
		
		while(rs.next()) 
		{
			
			CareProvider temp = new CareProvider(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			list.add(temp);
		} 
	return list;
	}
	
	
	/**
	 * 
	 * @return list
	 * @throws SQLException 
	 */
	public ObservableList<ProviderInfo> providerInfoListDisplay() throws SQLException
	{
		ObservableList<ProviderInfo> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select fostercareprovider.careProviderId,careproviderlastname, careproviderfirstname,areacode,phonenumber\r\n" + 
				"from fostercareprovider join careproviderpersonalphone\r\n" + 
				"where fostercareprovider.careProviderId = careproviderpersonalphone.careProviderId");
		
		while(rs.next()) 
		{ 
			ProviderInfo temp = new ProviderInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			list.add(temp);
		} 
		
	return list;
	}
	
	public ObservableList<LicenseRenewal> showLicenseRenewalRelation() throws SQLException
	{
		
		ObservableList<LicenseRenewal> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select *\r\n "+
		"from FosterCareHomeLicensing;");
		
		while(rs.next()) 
		{ 
			LicenseRenewal temp = new LicenseRenewal(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(9),rs.getString(6),rs.getString(7),rs.getString(8));
			list.add(temp);
		} 
		
	return list;
	}

	public ObservableList<FosterCareHome> showFosterHomeRelation() throws SQLException
	{
		
		ObservableList<FosterCareHome> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select *\r\n "+
		"from FosterHome;");
		
		while(rs.next()) 
		{ 
			FosterCareHome temp = new FosterCareHome(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
			list.add(temp);
		} 
		
	return list;
	}
	
	public ObservableList<MedicationChart> showMedChartRelation() throws SQLException
	{
		
		ObservableList<MedicationChart> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select *\r\n "+
		"from Medication;");
		
		while(rs.next()) 
		{ 
			MedicationChart temp = new MedicationChart(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
			list.add(temp);
		} 
		
	return list;
	}

	public ObservableList<PrimaryClinic> showPrimaryClinicRelation() throws SQLException
	{
		
		ObservableList<PrimaryClinic> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select *\r\n "+
		"from PrimaryClinic;");
		
		while(rs.next()) 
		{ 
			PrimaryClinic temp = new PrimaryClinic(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
			list.add(temp);
		} 
		
	return list;
	}
	
	public ObservableList<Client> showClientRelation() throws SQLException
	{
		
		ObservableList<Client> list = FXCollections.observableArrayList();
		
		st = con.createStatement();
		rs = st.executeQuery("select *\r\n "+
		"from fostercareclient;");
		
		while(rs.next()) 
		{ 
			Client temp = new Client(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
			list.add(temp);
		} 
		
	return list;
	}
	
	
}



		

