package application;

public class ProviderInfo {
	private String careProviderId;
	private String careProviderLastName;
	private String careProviderFirstName;
	private String areaCode;
	private String phoneNumber;
	
	
	public ProviderInfo(String careProviderId,String careProviderLastName, String careProviderFirstName, String areaCode, String phoneNumber) {
		this.careProviderId = careProviderId;
		this.careProviderLastName = careProviderLastName;
		this.careProviderFirstName = careProviderFirstName;
		this.areaCode = areaCode;
		this.phoneNumber = phoneNumber;
	}

	public String getCareProviderId() {
		return careProviderId;
	}


	public void setCareProviderId(String careProviderId) {
		this.careProviderId = careProviderId;
	}


	public String getCareProviderLastName() {
		return careProviderLastName;
	}


	public void setCareProviderLastName(String careProviderLastName) {
		this.careProviderLastName = careProviderLastName;
	}


	public String getCareProviderFirstName() {
		return careProviderFirstName;
	}


	public void setCareProviderFirstName(String careProviderFirstName) {
		this.careProviderFirstName = careProviderFirstName;
	}


	public String getAreaCode() {
		return areaCode;
	}


	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
