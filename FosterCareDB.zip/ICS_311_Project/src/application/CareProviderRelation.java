/**
 * 'Scene4' JavaFx Class contains specified layout information for Scene 4. The 'Scene4' JavaFx
 *  Class gives the user an organized view of cars added to the collection. 
 *  
 *  
 *  Source of borrowed code:
 *  URL: http://tutorials.jenkov.com/javafx/tableview.html
 *  GitHub: https://github.com/buckyroberts/Source-Code-from-Tutorials/blob/master/JavaFX/018_tableView/Main.java
 *  YouTube tutorial: https://www.youtube.com/watch?v=mtdlX2NMy4M
 * 
 * 
 * @author: Jon Prendergast
 * @since: 6/10/2019
 * @version: 1.0
 * 
 */
package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class CareProviderRelation {
	
	private BorderPane form2Layout;
	private FlowPane boxHolderPane;
	private VBox buttonHolder,createListBox,cloneListBox,displayListBox,tableBox;
	private Button refreshButton, returnButton, createListButton, cloneListButton, removeListButton;
	private Scene careProviderScene;
	private TableView<CareProvider> table;
	private Image image;
	private ImageView imageView;
	
	
	public CareProviderRelation() throws FileNotFoundException {
		
		//create table to hold column data for objects of type Car
		table = new TableView<CareProvider>();
		
		//create a refresh table button so that the table reflects most recent addition, deletions, and edits
		refreshButton = new Button("Display current list");

		//transition button from scene 4 to main menu (scene 1)
		returnButton = new Button("Return to main menu");
		
		//create an image and imageView
		image = new Image(new FileInputStream(".\\bin\\application\\night_sky.jpg"));
		imageView = new ImageView(image);
		imageView.setFitHeight(700);
		imageView.setFitWidth(1200);
		
		
		//create button holder VBox and add refresh/return to menu buttons
		buttonHolder = new VBox();
		buttonHolder.getChildren().addAll(refreshButton,returnButton);
		buttonHolder.setSpacing(10);
		buttonHolder.setMargin(refreshButton, new Insets(0,0,0,0));
		buttonHolder.setMargin(returnButton, new Insets(0,0,100,0));
		
		//create box holder and set horizontal spacing for VBox children
		boxHolderPane = new FlowPane();
		boxHolderPane.setHgap(20);
		boxHolderPane.setVgap(50);
		
		tableBox = new VBox();
		
		
		//add table node to tableBox
		tableBox.getChildren().add(table);
		
		//column 1 set up 
		TableColumn<CareProvider, String> column1 = new TableColumn<>("Care Provider ID");
		column1.setCellValueFactory(new PropertyValueFactory<>("careProviderId"));
		column1.setMinWidth(150);

		//column 2 set up
		TableColumn<CareProvider, String> column2 = new TableColumn<>("Foster Home ID");
		column2.setCellValueFactory(new PropertyValueFactory<>("fosterHomeId"));
		column2.setMinWidth(150);
		  
		//column 3 set up
		TableColumn<CareProvider, String> column3 = new TableColumn<>("Care Provider Last Name");
		column3.setCellValueFactory(new PropertyValueFactory<>("careProviderLastName"));
		column3.setMinWidth(150);
		
		//column 4 set up
		TableColumn<CareProvider, Integer> column4 = new TableColumn<>("Care Provider First Name");
		column4.setCellValueFactory(new PropertyValueFactory<>("careProviderFirstName"));
		column4.setMinWidth(150);
		
		//column 5 set up
		TableColumn<CareProvider, Integer> column5 = new TableColumn<>("Date of Birth");
		column5.setCellValueFactory(new PropertyValueFactory<>("dateOfBirth"));
		column5.setMinWidth(150);
		
		//column 6 set up
		TableColumn<CareProvider, Integer> column6 = new TableColumn<>("Date of Creation");
		column6.setCellValueFactory(new PropertyValueFactory<>("rowCreation"));
		column6.setMinWidth(150);
		
		//column 7 set up
		TableColumn<CareProvider, Integer> column7 = new TableColumn<>("Last Update");
		column7.setCellValueFactory(new PropertyValueFactory<>("rowUpdate"));
		column7.setMinWidth(150);
		
		  
		//add columns 1-6 to table
		table.getColumns().addAll(column1,column2,column3,column4,column5,column6,column7);
				
		//establish scene 4 border pane and add image to background
		form2Layout = new BorderPane();
		form2Layout.getChildren().add(imageView);
		
		//add the rest of the boxes to border pane 
		form2Layout.setCenter(tableBox);
		form2Layout.setTop(boxHolderPane);
		form2Layout.setBottom(buttonHolder);
		buttonHolder.setAlignment(Pos.TOP_CENTER);
		
		form2Layout.setMargin(tableBox, new Insets(100,50,0,50));
		
		//add scene 4 layout to scene 4
		careProviderScene = new Scene(form2Layout,850,700);
	}
	
	
	/**
	 * Method 'getRemoveListButton' returns access to removeListButton
	 * 
	 * @return: returnListButton
	 */
	public Button getRemoveListButton() {
		return removeListButton;
	}



	/**
	 * Method 'getButtonHolder' returns access to button holder VBox
	 * 
	 * @return: buttonHolder
	 */
	public VBox getButtonHolder() {
		return buttonHolder;
	}

	/**
	 * Method 'getCreateListBox' returns access to create list VBox
	 * 
	 * @return: createListBox
	 */
	public VBox getCreateListBox() {
		return createListBox;
	}
	
	/**
	 * Method 'getCloneListBox' returns access to clone list VBox
	 * 
	 * @return: cloneListBox
	 */
	public VBox getCloneListBox() {
		return cloneListBox;
	}
	
	/**
	 * Method 'getDisplayListBox' returns access to display list VBox
	 * 
	 * @return: displayListBox
	 */
	public VBox getDisplayListBox() {
		return displayListBox;
	}


	/**
	 * 'getScene4Layout' accesses the
	 * 	private instance variable scene4Layout
	 * 
	 * @return: scene4Layout
	 */
	public BorderPane getScene4Layout() {
		return form2Layout;
	}


	/**
	 * 'getSubmitButton' accesses the
	 * 	private instance variable submitButton
	 * 
	 * @return: submitButton
	 */
	public Button getRefreshButton() {
		return refreshButton;
	}


	/**
	 * 'getReturnButton' accesses the
	 * 	private instance variable returnButton
	 * 
	 * @return: returnButton
	 */
	public Button getReturnButton() {
		return returnButton;
	}

	/**
	 * 'getScene4' accesses the
	 * 	private instance variable scene4
	 * 
	 * @return: scene4
	 */
	public Scene getCareProviderRelationScene() {
		return careProviderScene;
	}


	/**
	 * 'getTable' accesses the
	 * 	private instance variable table
	 * 
	 * @return: table
	 */
	public TableView<CareProvider> getTable() {
		return table;
	}
	
	/**
	 * Method 'getCreateListButton' returns access to createListButton
	 * 
	 * @return: createListButton
	 */
	public Button getCreateListButton() {
		return createListButton;
	}

	/**
	 * Method 'getCloneListButton' returns access to cloneListButton
	 * 
	 * @return: cloneListButton
	 */
	public Button getCloneListButton() {
		return cloneListButton;
	}
}
