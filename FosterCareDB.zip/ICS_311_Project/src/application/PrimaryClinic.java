package application;

public class PrimaryClinic {
	
	private String primaryClinicId;
	private String physicianLastName;
	private String physicianFirstName;
	private String primaryClinicStreet;
	private String primaryClinicCity;
	private String primaryClinicState;
	private String rowCreationDate;
	private String latestRowUpdate;
	
	
	public PrimaryClinic(String primaryClinicId, String physicianLastName, String physicianFirstName,
			String primaryClinicStreet, String primaryClinicCity, String primaryClinicState, String rowCreationDate,
			String latestRowUpdate) {
		super();
		this.primaryClinicId = primaryClinicId;
		this.physicianLastName = physicianLastName;
		this.physicianFirstName = physicianFirstName;
		this.primaryClinicStreet = primaryClinicStreet;
		this.primaryClinicCity = primaryClinicCity;
		this.primaryClinicState = primaryClinicState;
		this.rowCreationDate = rowCreationDate;
		this.latestRowUpdate = latestRowUpdate;
	}


	public String getPrimaryClinicId() {
		return primaryClinicId;
	}


	public void setPrimaryClinicId(String primaryClinicId) {
		this.primaryClinicId = primaryClinicId;
	}


	public String getPhysicianLastName() {
		return physicianLastName;
	}


	public void setPhysicianLastName(String physicianLastName) {
		this.physicianLastName = physicianLastName;
	}


	public String getPhysicianFirstName() {
		return physicianFirstName;
	}


	public void setPhysicianFirstName(String physicianFirstName) {
		this.physicianFirstName = physicianFirstName;
	}


	public String getPrimaryClinicStreet() {
		return primaryClinicStreet;
	}


	public void setPrimaryClinicStreet(String primaryClinicStreet) {
		this.primaryClinicStreet = primaryClinicStreet;
	}


	public String getPrimaryClinicCity() {
		return primaryClinicCity;
	}


	public void setPrimaryClinicCity(String primaryClinicCity) {
		this.primaryClinicCity = primaryClinicCity;
	}


	public String getPrimaryClinicState() {
		return primaryClinicState;
	}


	public void setPrimaryClinicState(String primaryClinicState) {
		this.primaryClinicState = primaryClinicState;
	}


	public String getRowCreationDate() {
		return rowCreationDate;
	}


	public void setRowCreationDate(String rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}


	public String getLatestRowUpdate() {
		return latestRowUpdate;
	}

	public void setLatestRowUpdate(String latestRowUpdate) {
		this.latestRowUpdate = latestRowUpdate;
	}
}
