package application;

public class MedicationChart {
	private String medicationId;
	private String medicationStartDate;
	private String medicationEndDate;
	private String medicationName;
	private String medicationDosage;
	private String numberOfDailyDoses;
	private String clientId;
	private String rowCreationDate;
	private String latestRowUpdate;
	

	public MedicationChart(String medicationId, String medicationStartDate, String medicationEndDate,
			String medicationName, String medicationDosage, String numberOfDailyDoses, String clientId,
			String rowCreationDate, String latestRowUpdate) {
		this.medicationId = medicationId;
		this.medicationStartDate = medicationStartDate;
		this.medicationEndDate = medicationEndDate;
		this.medicationName = medicationName;
		this.medicationDosage = medicationDosage;
		this.numberOfDailyDoses = numberOfDailyDoses;
		this.clientId = clientId;
		this.rowCreationDate = rowCreationDate;
		this.latestRowUpdate = latestRowUpdate;
	}
	
	
	public String getMedicationId() {
		return medicationId;
	}
	public void setMedicationId(String medicationId) {
		this.medicationId = medicationId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getMedicationStartDate() {
		return medicationStartDate;
	}
	public void setMedicationStartDate(String medicationStartDate) {
		this.medicationStartDate = medicationStartDate;
	}
	public String getMedicationEndDate() {
		return medicationEndDate;
	}
	public void setMedicationEndDate(String medicationEndDate) {
		this.medicationEndDate = medicationEndDate;
	}
	public String getMedicationName() {
		return medicationName;
	}
	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}
	public String getMedicationDosage() {
		return medicationDosage;
	}
	public void setMedicationDosage(String medicationDosage) {
		this.medicationDosage = medicationDosage;
	}
	public String getNumberOfDailyDoses() {
		return numberOfDailyDoses;
	}
	public void setNumberOfDailyDoses(String numberOfDailyDoses) {
		this.numberOfDailyDoses = numberOfDailyDoses;
	}
	public String getRowCreationDate() {
		return rowCreationDate;
	}
	public void setRowCreationDate(String rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}
	public String getLatestRowUpdate() {
		return latestRowUpdate;
	}
	public void setLatestRowUpdate(String latestRowUpdate) {
		this.latestRowUpdate = latestRowUpdate;
	}
	
	
	
	
	

}
