package application;

public class FosterCareHome {
	
	private String fosterHomeId;
	private String fosterHomeStreet;
	private String fosterHomeCity;
	private String fosterHomeState;		
	private String fosterHomeZip;
	private String numberOfOccupants;
	private String licensingId;
	private String rowCreationDate;
	private String latestRowUpdate;
	
	
	public FosterCareHome(String fosterHomeId, String fosterHomeStreet, String fosterHomeCity, String fosterHomeState,
			String fosterHomeZip, String numberOfOccupants, String licensingId, String rowCreationDate,
			String latestRowUpdate) {
		this.fosterHomeId = fosterHomeId;
		this.fosterHomeStreet = fosterHomeStreet;
		this.fosterHomeCity = fosterHomeCity;
		this.fosterHomeState = fosterHomeState;
		this.fosterHomeZip = fosterHomeZip;
		this.numberOfOccupants = numberOfOccupants;
		this.licensingId = licensingId;
		this.rowCreationDate = rowCreationDate;
		this.latestRowUpdate = latestRowUpdate;
	}
	public String getFosterHomeId() {
		return fosterHomeId;
	}
	public void setFosterHomeId(String fosterHomeId) {
		this.fosterHomeId = fosterHomeId;
	}
	public String getFosterHomeStreet() {
		return fosterHomeStreet;
	}
	public void setFosterHomeStreet(String fosterHomeStreet) {
		this.fosterHomeStreet = fosterHomeStreet;
	}
	public String getFosterHomeCity() {
		return fosterHomeCity;
	}
	public void setFosterHomeCity(String fosterHomeCity) {
		this.fosterHomeCity = fosterHomeCity;
	}
	public String getFosterHomeState() {
		return fosterHomeState;
	}
	public void setFosterHomeState(String fosterHomeState) {
		this.fosterHomeState = fosterHomeState;
	}
	public String getFosterHomeZip() {
		return fosterHomeZip;
	}
	public void setFosterHomeZip(String fosterHomeZip) {
		this.fosterHomeZip = fosterHomeZip;
	}
	public String getNumberOfOccupants() {
		return numberOfOccupants;
	}
	public void setNumberOfOccupants(String numberOfOccupants) {
		this.numberOfOccupants = numberOfOccupants;
	}
	public String getLicensingId() {
		return licensingId;
	}
	public void setLicensingId(String licensingId) {
		this.licensingId = licensingId;
	}
	public String getRowCreationDate() {
		return rowCreationDate;
	}
	public void setRowCreationDate(String rowCreationDate) {
		this.rowCreationDate = rowCreationDate;
	}
	public String getLatestRowUpdate() {
		return latestRowUpdate;
	}
	public void setLatestRowUpdate(String latestRowUpdate) {
		this.latestRowUpdate = latestRowUpdate;
	}
}
