package application;

public class CareProvider {
	private String careProviderId;
	private String fosterHomeId;
	private String careProviderLastName;
	private String careProviderFirstName;
	private String dateOfBirth;
	private String rowCreation;
	private String rowUpdate;
	

	public CareProvider(String careProviderId, String fosterHomeId, String careProviderLastName,
			String careProviderFirstName, String dateOfBirth, String rowCreation, String rowUpdate) {
		this.careProviderId = careProviderId;
		this.fosterHomeId = fosterHomeId;
		this.careProviderLastName = careProviderLastName;
		this.careProviderFirstName = careProviderFirstName;
		this.dateOfBirth = dateOfBirth;
		this.rowCreation = rowCreation;
		this.rowUpdate = rowUpdate;
	}
	
	
	public String getCareProviderId() {
		return careProviderId;
	}



	public void setCareProviderId(String careProviderId) {
		this.careProviderId = careProviderId;
	}



	public String getFosterHomeId() {
		return fosterHomeId;
	}



	public void setFosterHomeId(String fosterHomeId) {
		this.fosterHomeId = fosterHomeId;
	}



	public String getCareProviderLastName() {
		return careProviderLastName;
	}



	public void setCareProviderLastName(String careProviderLastName) {
		this.careProviderLastName = careProviderLastName;
	}



	public String getCareProviderFirstName() {
		return careProviderFirstName;
	}



	public void setCareProviderFirstName(String careProviderFirstName) {
		this.careProviderFirstName = careProviderFirstName;
	}



	public String getDateOfBirth() {
		return dateOfBirth;
	}



	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public String getRowCreation() {
		return rowCreation;
	}



	public void setRowCreation(String rowCreation) {
		this.rowCreation = rowCreation;
	}



	public String getRowUpdate() {
		return rowUpdate;
	}



	public void setRowUpdate(String rowUpdate) {
		this.rowUpdate = rowUpdate;
	}
}
