/**
 * 'Scene4' JavaFx Class contains specified layout information for Scene 4. The 'Scene4' JavaFx
 *  Class gives the user an organized view of cars added to the collection. 
 *  
 *  
 *  Source of borrowed code:
 *  URL: http://tutorials.jenkov.com/javafx/tableview.html
 *  GitHub: https://github.com/buckyroberts/Source-Code-from-Tutorials/blob/master/JavaFX/018_tableView/Main.java
 *  YouTube tutorial: https://www.youtube.com/watch?v=mtdlX2NMy4M
 * 
 * 
 * @author: Jon Prendergast
 * @since: 6/10/2019
 * @version: 1.0
 * 
 */
package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class PrimaryClinicRelation {
	
	private BorderPane form3Layout;
	private FlowPane boxHolderPane;
	private VBox buttonHolder,createListBox,cloneListBox,displayListBox,tableBox;
	private Button refreshButton, returnButton,displayListButton;
	private Scene additionalProviderInfoScene;
	private TableView<PrimaryClinic> table;
	private Image image;
	private ImageView imageView;
	
	
	public PrimaryClinicRelation() throws FileNotFoundException {
		
		//create table to hold column data for objects of type Car
		table = new TableView<PrimaryClinic>();
		
		//create a refresh table button so that the table reflects most recent addition, deletions, and edits
		refreshButton = new Button("Display current list");

		//transition button from scene 4 to main menu (scene 1)
		returnButton = new Button("Return to Menu");
		
		//create an image and imageView
		image = new Image(new FileInputStream(".\\bin\\application\\night_sky.jpg"));
		imageView = new ImageView(image);
		imageView.setFitHeight(1200);
		imageView.setFitWidth(1200);
		
		
		//create button holder VBox and add refresh/return to menu buttons
		buttonHolder = new VBox();
		buttonHolder.getChildren().addAll(refreshButton,returnButton);
		buttonHolder.setSpacing(10);
		buttonHolder.setMargin(refreshButton, new Insets(0,0,0,0));
		buttonHolder.setMargin(returnButton, new Insets(0,0,100,0));
		
		//create box holder and set horizontal spacing for VBox children
		boxHolderPane = new FlowPane();
		boxHolderPane.setHgap(20);
		boxHolderPane.setVgap(50);
		
		tableBox = new VBox();
		
		
		//add table node to tableBox
		tableBox.getChildren().add(table);
		  
		//column 3 set up
		TableColumn<PrimaryClinic, String> column3 = new TableColumn<>("Primary Clinic ID");
		column3.setCellValueFactory(new PropertyValueFactory<>("primaryClinicId"));
		column3.setMinWidth(150);
		
		//column 4 set up
		TableColumn<PrimaryClinic, String> column4 = new TableColumn<>("Physician Last Name");
		column4.setCellValueFactory(new PropertyValueFactory<>("physicianLastName"));
		column4.setMinWidth(150);
		
		//column 5 set up
		TableColumn<PrimaryClinic, String> column5 = new TableColumn<>("Physician First Name");
		column5.setCellValueFactory(new PropertyValueFactory<>("physicianFirstName"));
		column5.setMinWidth(150);
		
		//column 6 set up
		TableColumn<PrimaryClinic, String> column6 = new TableColumn<>("Primary Clinic Street");
		column6.setCellValueFactory(new PropertyValueFactory<>("primaryClinicStreet"));
		column6.setMinWidth(150);
		
		//column 7 set up
		TableColumn<PrimaryClinic, String> column7 = new TableColumn<>("Primary Clinic City");
		column7.setCellValueFactory(new PropertyValueFactory<>("primaryClinicCity"));
		column7.setMinWidth(150);
		
		//column 8 set up
		TableColumn<PrimaryClinic, String> column8 = new TableColumn<>("Primary Clinic State");
		column8.setCellValueFactory(new PropertyValueFactory<>("primaryClinicState"));
		column8.setMinWidth(150);
		
		//column 9 set up
		TableColumn<PrimaryClinic, String> column9 = new TableColumn<>("Row Creation Date");
		column9.setCellValueFactory(new PropertyValueFactory<>("rowCreationDate"));
		column9.setMinWidth(150);
		
		//column 10 set up
		TableColumn<PrimaryClinic, String> column10 = new TableColumn<>("Latest Row Update");
		column10.setCellValueFactory(new PropertyValueFactory<>("latestRowUpdate"));
		column10.setMinWidth(150);

		

		//add columns 1-6 to table
		table.getColumns().addAll(column3,column4,column5,column6,column7,column8, column9,column10);
				
		//establish scene 4 border pane and add image to background
		form3Layout = new BorderPane();
		form3Layout.getChildren().add(imageView);
		
		//add the rest of the boxes to border pane 
		form3Layout.setCenter(tableBox);
		form3Layout.setTop(boxHolderPane);
		form3Layout.setBottom(buttonHolder);
		buttonHolder.setAlignment(Pos.TOP_CENTER);
		
		form3Layout.setMargin(tableBox, new Insets(100,50,0,50));
		
		//add scene 4 layout to scene 4
		additionalProviderInfoScene = new Scene(form3Layout,850,700);
	}
	

	/**
	 * Method 'getButtonHolder' returns access to button holder VBox
	 * 
	 * @return: buttonHolder
	 */
	public VBox getButtonHolder() {
		return buttonHolder;
	}

	/**
	 * Method 'getCreateListBox' returns access to create list VBox
	 * 
	 * @return: createListBox
	 */
	public VBox getCreateListBox() {
		return createListBox;
	}
	
	/**
	 * Method 'getCloneListBox' returns access to clone list VBox
	 * 
	 * @return: cloneListBox
	 */
	public VBox getCloneListBox() {
		return cloneListBox;
	}
	
	/**
	 * Method 'getDisplayListBox' returns access to display list VBox
	 * 
	 * @return: displayListBox
	 */
	public VBox getDisplayListBox() {
		return displayListBox;
	}


	/**
	 * 'getScene4Layout' accesses the
	 * 	private instance variable scene4Layout
	 * 
	 * @return: scene4Layout
	 */
	public BorderPane getScene4Layout() {
		return form3Layout;
	}


	/**
	 * 'getSubmitButton' accesses the
	 * 	private instance variable submitButton
	 * 
	 * @return: submitButton
	 */
	public Button getRefreshButton() {
		return refreshButton;
	}


	/**
	 * 'getReturnButton' accesses the
	 * 	private instance variable returnButton
	 * 
	 * @return: returnButton
	 */
	public Button getReturnButton() {
		return returnButton;
	}

	/**
	 * 'getScene4' accesses the
	 * 	private instance variable scene4
	 * 
	 * @return: scene4
	 */
	public Scene getAdditionalProviderInfoScene() {
		return additionalProviderInfoScene;
	}


	/**
	 * 'getTable' accesses the
	 * 	private instance variable table
	 * 
	 * @return: table
	 */
	public TableView<PrimaryClinic> getTable() {
		return table;
	}
	

	/**
	 * Method 'getDisplayListButton' returns access to displayListButton
	 * 
	 * @return: displayListButton
	 */
	public Button getDisplayListButton() {
		return displayListButton;
	}
}
