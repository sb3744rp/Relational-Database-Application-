package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class Form {
	
	private TextField careProviderIdForm,careProviderStreetAddressForm,careProviderCityForm,careProviderStateForm,careProviderZipForm;
	private Label careProviderIdLabel, careProviderStreetAddressLabel,careProviderCityLabel,careProviderStateLabel,careProviderZipLabel;
	private Button careProviderSubmitButton,forward,backward, returnToMenu;
	private GridPane form2Pane;
	private VBox form2Box;
	private BorderPane holdsAll;
	private FlowPane holdsButtons;
	private Scene scene1;
	
	public Form() {
		
		// set up text field for user input
		careProviderIdForm = new TextField(); 
		careProviderIdForm.setMaxWidth(250);
		
		//FlowPane to hold buttons
		holdsButtons = new FlowPane();
		
		// set up text fields to display info based on provided input
		careProviderStreetAddressForm = new TextField();
		careProviderCityForm = new TextField();
		careProviderStateForm = new TextField();
		careProviderZipForm = new TextField();
		
		// set up label care provider id prompt
		careProviderIdLabel = new Label(); 
		careProviderIdLabel.setText("Care Provider Id: ");
		
		// set up labels for foster home display information 
		careProviderStreetAddressLabel = new Label();
		careProviderStreetAddressLabel.setText("Foster Home Street Address");
		
		careProviderCityLabel = new Label();
		careProviderCityLabel.setText("Foster Home City");
		
		careProviderStateLabel = new Label();
		careProviderStateLabel.setText("Foster Home State");
		
		careProviderZipLabel = new Label();
		careProviderZipLabel.setText("Foster Home Zip");
		
		// set up submit, forward, and backward buttons for action events
		careProviderSubmitButton = new Button("Submit");
		forward = new Button("Next");
		backward = new Button("Previous");
		returnToMenu = new Button("Return to menu");
		
		//create button holder
		holdsButtons.getChildren().addAll(backward,careProviderSubmitButton,forward,returnToMenu);
		holdsButtons.setHgap(10);
		holdsButtons.setVgap(10);
		
		//create grid pane to holds foster home labels and forms 
		form2Pane = new GridPane();
		form2Pane.setHgap(25);
		form2Pane.setVgap(25);
		
		// add foster home street address label and form to grid pane
		form2Pane.add(careProviderStreetAddressLabel, 0, 0, 2, 1);
		form2Pane.add(careProviderStreetAddressForm, 3, 0, 2, 1);
		
		// add foster home city label and form to grid pane
		form2Pane.add(careProviderCityLabel, 0, 1, 2, 1);
		form2Pane.add(careProviderCityForm, 3, 1, 2, 1);
		
		// add foster home state label and form to grid pane
		form2Pane.add(careProviderStateLabel, 0, 2, 2, 1);
		form2Pane.add(careProviderStateForm, 3, 2, 2, 1);
		
		// add foster home zip label and form to grid pane
		form2Pane.add(careProviderZipLabel, 0, 3, 2, 1);
		form2Pane.add(careProviderZipForm, 3, 3, 2, 1);

		// create VBox to hold foster care provider id label, form and submit button
		form2Box = new VBox();
		form2Box.getChildren().addAll(careProviderIdLabel,careProviderIdForm,holdsButtons);
		form2Box.setAlignment(Pos.TOP_CENTER);
		form2Box.setSpacing(10);
		holdsButtons.setAlignment(Pos.CENTER);
		
		//create borderpane to hold grid pane and vbox
		holdsAll = new BorderPane();
		holdsAll.setTop(form2Box);
		holdsAll.setCenter(form2Pane);
		
		//adjust margins to align scene objects 
		holdsAll.setMargin(form2Box, new Insets(40,50,10,50));
		holdsAll.setMargin(form2Pane, new Insets(60,50,10,50));
	
		//create scene object 
		scene1 = new Scene(holdsAll,500,500);
	}
	
	
	public Button getReturnToMenu() {
		return returnToMenu;
	}


	public Button getForward() {
		return forward;
	}


	public Button getBackward() {
		return backward;
	}

	public void setCareProvdiderIdForm(String careProviderId) {
		this.careProviderIdForm.setText(careProviderId);	
	}


	public TextField getCareProvdiderIdForm() {
		return careProviderIdForm;
	}

	public TextField getCareProviderStreetAddressForm() {
		return careProviderStreetAddressForm;
	}

	public TextField getCareProviderCityForm() {
		return careProviderCityForm;
	}

	public TextField getCareProviderStateForm() {
		return careProviderStateForm;
	}

	public TextField getCareProviderZipForm() {
		return careProviderZipForm;
	}

	public Label getCareProviderIdLabel() {
		return careProviderIdLabel;
	}

	public Label getCareProviderStreetAddressLabel() {
		return careProviderStreetAddressLabel;
	}

	public Label getCareProviderCityLabel() {
		return careProviderCityLabel;
	}

	public Label getCareProviderStateLabel() {
		return careProviderStateLabel;
	}

	public Label getCareProviderZipLabel() {
		return careProviderZipLabel;
	}

	public Button getCareProviderSubmitButton() {
		return careProviderSubmitButton;
	}

	public GridPane getForm2Pane() {
		return form2Pane;
	}

	public VBox getForm2Box() {
		return form2Box;
	}

	public BorderPane getHoldsAll() {
		return holdsAll;
	}

	public Scene getScene() {
		return scene1;
	}
}
